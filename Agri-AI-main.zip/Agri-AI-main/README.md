# Agri-AI 🌿

Agri-AI is a deep learning project to identify plant species and their diseases using images of leaves. The goal is to help farmers and researchers detect diseases early and suggest remedies in future versions.

---

## 💡 Features

- Built from scratch using Vision Transformer (ViT)
- Detects plant species and disease from leaf image
- Saves best model and checkpoint
- Can resume training from last checkpoint
- Future Scope: Suggest remedies based on disease

---

## 🗂 Dataset Structure

Your dataset should be structured like this:

